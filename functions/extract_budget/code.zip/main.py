import json
import re
import pdfplumber
import io
from appwrite.client import Client
from appwrite.services.storage import Storage

def parse_number(s):
    if not s or s.strip() == '-' or s.strip() == '0.00' or s.strip() == '.':
        return 0
    s = s.strip().replace(',', '')
    if s.startswith('(') and s.endswith(')'):
        s = '-' + s[1:-1]
    # Remove any trailing non-numeric chars
    s = re.sub(r'[^\d.-]', '', s)
    try:
        return float(s)
    except ValueError:
        return 0

def main(context):
    # Appwrite Function Context
    # payload is the JSON body sent from the frontend
    payload = context.req.body
    if not payload:
        return context.res.json({"error": "No payload provided"}, 400)
    
    if isinstance(payload, str):
        payload = json.loads(payload)

    file_id = payload.get('fileId')
    bucket_id = payload.get('bucketId')

    if not file_id or not bucket_id:
        return context.res.json({"error": "Missing fileId or bucketId"}, 400)

    # Initialize Appwrite SDK
    client = Client()
    client.set_endpoint(context.variables.get('VITE_APPWRITE_ENDPOINT'))
    client.set_project(context.variables.get('VITE_APPWRITE_PROJECT_ID'))
    client.set_key(context.variables.get('APPWRITE_API_KEY'))

    storage = Storage(client)

    try:
        # Download file from Storage
        file_bytes = storage.get_file_download(bucket_id, file_id)
        
        data = {
            "state": "Unknown",
            "year": 2024,
            "summary": {},
            "summarySources": {},
            "sectors": [],
            "mdas": {}
        }

        with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
            all_text = ""
            for page in pdf.pages:
                text = page.extract_text(layout=True)
                if text:
                    all_text += text + "\n"

            data["raw_text"] = all_text # Add raw text for frontend preview
            lines = all_text.split('\n')

            # 1. Detect State and Year
            for line in lines[:20]:
                if "Government" in line and ("Approved Budget" in line or "Estimates" in line):
                    match = re.search(r'([A-Za-z]+)\s+State', line)
                    if match:
                        data["state"] = match.group(1)
                    year_match = re.search(r'(20\d{2})', line)
                    if year_match:
                        data["year"] = int(year_match.group(1))

            # 2. Parse Summary
            summary_map = {
                "recurrent_revenue": ["Recurrent Revenue", "Total Recurrent Revenue"],
                "faac": ["GOVERNMENT SHARE OF FAAC", "Statutory Allocation"],
                "igr": ["INDEPENDENT REVENUE", "Internally Generated Revenue"],
                "grants": ["AID AND GRANTS", "Grants"],
                "capital_receipts": ["CAPITAL DEVELOPMENTFUND (CDF) RECEIPTS", "CDF RECEIPTS"],
                "personnel_cost": ["Personnel Cost", "Total Personnel"],
                "other_recurrent_costs": ["Other Recurrent Costs", "Overhead Cost"],
                "capital_expenditure": ["Capital Expenditure"],
                "total_revenue": ["Total Revenue"],
                "total_expenditure": ["Total Expenditure"]
            }

            for line in lines[:500]:
                upper_line = line.upper()
                for field, keywords in summary_map.items():
                    for kw in keywords:
                        if kw.upper() in upper_line:
                            matches = re.findall(r'[\d,]+\.\d{2}', line)
                            if matches:
                                val = parse_number(matches[-1])
                                if val > 0:
                                    data["summary"][field] = val
                                    data["summarySources"][field] = line.strip()

            # 3. Parse Functional (Sectors)
            # Pattern: 709 EDUCATION 10,000.00 ...
            sector_pattern = re.compile(r'^(7\d{2})\s+([A-Z,\s&/]+?)\s{2,}([\d,.-]+)\s+([\d,.-]+)\s+([\d,.-]+)\s+([\d,.-]+)$')
            in_functional = False
            for line in lines:
                if "Total Expenditure by Functional Classification" in line:
                    in_functional = True
                    continue
                if in_functional:
                    if "Personnel Expenditure" in line or "Administrative" in line:
                        in_functional = False
                        continue
                    match = sector_pattern.match(line.strip())
                    if match:
                        code, name, a22, b23, p23, b24 = match.groups()
                        if len(code) == 3:
                            data["sectors"].append({
                                "code": code,
                                "name": name.strip(),
                                "amount": parse_number(b24)
                            })

            # 4. Parse Administrative (MDAs)
            section_map = {
                "Total Expenditure by Administrative Classification": "total",
                "Personnel Expenditure by Administrative Classification": "personnel",
                "Other Non-Debt Recurrent Expenditure by Administrative Classification": "overhead",
                "Capital Expenditure by Administrative Classification": "capital"
            }
            mda_row_pattern = re.compile(r'^(\d{12})\s+([A-Za-z\s&/.,()\-’]+?)\s{2,}([\d,.-]+)\s+([\d,.-]+)\s+([\d,.-]+)\s+([\d,.-]+)$')
            current_section = None
            for line in lines:
                stripped = line.strip()
                for title, key in section_map.items():
                    if title in stripped:
                        current_section = key
                        break
                if not current_section:
                    continue
                match = mda_row_pattern.match(stripped)
                if match:
                    code, name, a22, b23, p23, b24 = match.groups()
                    val = parse_number(b24)
                    if code not in data["mdas"]:
                        data["mdas"][code] = {
                            "code": code,
                            "name": name.strip(),
                            "total": 0,
                            "personnel": 0,
                            "overhead": 0,
                            "capital": 0,
                            "sourceLine": stripped
                        }
                    data["mdas"][code][current_section] = val

        # Clean MDAs
        mda_list = []
        for code, info in data["mdas"].items():
            if info["total"] == 0:
                info["total"] = info["personnel"] + info["overhead"] + info["capital"]
            if info["total"] > 0:
                mda_list.append(info)
        
        mda_list.sort(key=lambda x: x["total"], reverse=True)
        data["mdas"] = mda_list

        return context.res.json(data)

    except Exception as e:
        context.error(str(e))
        return context.res.json({"error": str(e)}, 500)
